import java.util.Scanner;

public class a {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x,y,res;
		System.out.println("Digite um n�mero:");
		x = sc.nextInt();
		System.out.println("Digite outro n�mero");
		y = sc.nextInt();
		
		res = x-y;
		sc.close();
		System.out.println("A subtra��o �: "+res);
		

	}

}
