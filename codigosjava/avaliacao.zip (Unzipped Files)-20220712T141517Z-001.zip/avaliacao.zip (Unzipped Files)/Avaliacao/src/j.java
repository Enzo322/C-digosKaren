import java.util.Scanner;

public class j {

	public static void main(String[] args) {
		Double qtddin,dindolar,dineuro,dinlibra;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite a quantidade de dinheiro que vc tem: ");
		qtddin = sc.nextDouble();
		
		dindolar = qtddin * 4.97;
		dineuro = qtddin * 5.23;
		dinlibra = qtddin * 6.24;
		sc.close();
		System.out.println("para dolar: "+dindolar);
		System.out.println("para euro: "+dineuro);
		System.out.println("para libra: "+dinlibra);



	}

}
