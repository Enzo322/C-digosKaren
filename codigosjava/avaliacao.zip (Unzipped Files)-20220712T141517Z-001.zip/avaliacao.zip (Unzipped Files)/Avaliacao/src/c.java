import java.util.Scanner;

public class c {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double num1,num2,res;
		
		System.out.println("N�mero(sem zeros :)):");
		num1 = sc.nextDouble();
		System.out.println("N�mero:");
		num2 = sc.nextDouble();
		
		res = num1/num2;
		sc.close();
		System.out.println("A divis�o �: "+res);
	}

}
