import java.util.Scanner;

public class e {

	public static void main(String[] args) {
		double sal,venda,com,salfinal;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite seu sal�rio:");
		sal = sc.nextDouble();
		System.out.println("Digite seu sal�rio:");
		venda = sc.nextDouble();
		
		com = venda*0.04;
		salfinal = sal + com;
		sc.close();
		System.out.println("Seu novo sal�rio � de: "+salfinal);

	}

}
