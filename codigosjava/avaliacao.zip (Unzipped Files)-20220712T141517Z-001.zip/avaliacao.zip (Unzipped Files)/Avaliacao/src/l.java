import java.util.Scanner;

public class l {

	public static void main(String[] args) {
		double custo,ingresso,qtd;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Custo:");
		custo = sc.nextDouble();
		System.out.println("Ingresso:");
		ingresso = sc.nextDouble();
		
		qtd = custo/ingresso;
		sc.close();
		System.out.println("A quantidade de ingressos dever� ser de: "+qtd);
		
	}

}
