import java.util.Scanner;

public class m {

	public static void main(String[] args) {
		double sal,qtdW,Kw,Wtotal,desconto;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Sal�rio:");
		sal = sc.nextDouble();
		System.out.println("QuiloWhatts consumido na resid�ncia:");
		qtdW = sc.nextDouble();
		
		Kw = sal/5;
		Wtotal = Kw * qtdW;
		desconto = Wtotal*0.85;
		sc.close();
		System.out.println("vai ser pago o total de: "+desconto);
	}

}
