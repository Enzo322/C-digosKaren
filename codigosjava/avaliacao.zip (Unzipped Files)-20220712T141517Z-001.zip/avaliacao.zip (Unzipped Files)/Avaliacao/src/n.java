import java.util.Scanner;

public class n {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double saco,qtdracao,gsaco,dia5,kg;
		
		System.out.println("Peso do saco:");
		saco = sc.nextDouble();
		System.out.println("Qtd ra��o:");
		qtdracao = sc.nextDouble();
		
		gsaco = saco*1000;
		
		dia5 = gsaco - ((qtdracao*2)*5);
		kg = dia5/1000;
		sc.close();
		System.out.println(kg);
	}

}
