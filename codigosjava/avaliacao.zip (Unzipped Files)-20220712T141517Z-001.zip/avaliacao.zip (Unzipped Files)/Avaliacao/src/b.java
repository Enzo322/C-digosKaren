import java.util.Scanner;

public class b {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a,b,c,res;
		
		System.out.println("N�mero:");
		a = sc.nextInt();
		System.out.println("N�mero:");
		b = sc.nextInt();
		System.out.println("N�mero:");
		c = sc.nextInt();
		
		res = a*b*c;
		sc.close();
		System.out.println("Resultado da multiplica��o: "+res);

	}

}
