import java.util.Scanner;

public class f {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double sal,minimo,qtdsalario;
		
		System.out.println("Sal�rio m�nimo:");
		minimo = sc.nextDouble();
		System.out.println("Sal�rio:");
		sal = sc.nextDouble();
		
		qtdsalario = sal/minimo;
		sc.close();
		System.out.println("A quantidade de sal�rios m�nimos que voc� recebe � de: "+qtdsalario);
		

	}

}
