import java.util.Scanner;

public class k {

	public static void main(String[] args) {
		double hrs,min,hrsmin,totalmin,minseg;
		Scanner sc = new Scanner(System.in);
				
		System.out.println("Horas:");
		hrs = sc.nextDouble();
		System.out.println("Minutos:");
		min = sc.nextDouble();
		
		hrsmin = hrs*60;
		totalmin = hrsmin+min;
		minseg = (totalmin+min)*60;
		
		System.out.println(hrs+"hrs = "+hrsmin);
		System.out.println("o total de minutos �: "+totalmin);
		System.out.println("O total de seg �: "+minseg);
		
		sc.close();
	}

}
