import java.util.Scanner;

public class h {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double sal,conta1,conta2,finalconta1,finalconta2,salfinal;
		System.out.println("Digite seu sal�rio:");
		sal = sc.nextDouble();
		System.out.println("Digite o valor de sua conta:");
		conta1 = sc.nextDouble();
		System.out.println("Digite o valor de sua outra conta:");
		conta2 = sc.nextDouble();
		
		finalconta1 = conta1*1.02;
		finalconta2 = conta2*1.02;
		salfinal = sal - finalconta1 - finalconta2;
		sc.close();
		System.out.println("Seu sal�rio � de: "+salfinal);
	}

}
