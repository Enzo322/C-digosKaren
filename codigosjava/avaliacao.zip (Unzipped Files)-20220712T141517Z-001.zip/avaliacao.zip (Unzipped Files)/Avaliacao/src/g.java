import java.util.Scanner;

public class g {

	public static void main(String[] args) {
		int num,res;
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite um n�mero:");
		num = sc.nextInt();
		for (int i=0;i<=10;i++) {
			res = num * i;
			System.out.println(num+" x "+i+" = "+res);
		}
		sc.close();
	}

}
