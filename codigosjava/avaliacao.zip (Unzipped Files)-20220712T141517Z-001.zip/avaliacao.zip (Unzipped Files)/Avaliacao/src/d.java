import java.util.Scanner;

public class d {

	public static void main(String[] args) {
		double prod,desc;
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite o pre�o do produto:");
		prod = sc.nextDouble();
		
		desc = prod*0.90;
		
		sc.close();
		System.out.println("O desconto de 10% sobre seu produto � de: "+desc);

	}

}
