import java.util.Scanner;

public class i {

	public static void main(String[] args) {
		double hrs,sal,extras,salhoras,valextras,salbruto,salextras,salfinal;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite o n�mero de horas trabalhadas:");
		hrs = sc.nextDouble();
		System.out.println("Digite seu sal�rio m�nimo:");
		sal = sc.nextDouble();
		System.out.println("Digite as suas horas extras:");
		extras = sc.nextDouble();
		
		salhoras = sal/8;
		valextras = sal/4;
		salbruto = hrs * salhoras;
		salextras = valextras * extras;
		salfinal = salbruto*salextras;
		sc.close();
		System.out.println("O sal�rio final � de: "+salfinal);
		
		

	}

}
