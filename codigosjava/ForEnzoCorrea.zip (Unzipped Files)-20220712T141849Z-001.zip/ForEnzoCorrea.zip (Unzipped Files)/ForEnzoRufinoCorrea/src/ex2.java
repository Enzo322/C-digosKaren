import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String time;
		String txt = "", txt2 = "";
		int contIdade = 0;
		double media, mediaIdade = 0, mediaAltura = 0, somaPeso = 0;
		int i,j = 0;
		for (i = 1; i <= 11; i++) {
			System.out.println("Digite o nome do time:");
			time = sc.next();
			for (j = 1; j <= 3; j++) {
				System.out.println("Nome do Jogador:");
				String nome = sc.next();

				System.out.println("Idade:");
				int idade = sc.nextInt();

				System.out.println("Peso:");
				double peso = sc.nextDouble();

				System.out.println("Altura:");
				double alt = sc.nextDouble();

				txt += "Nome do jogador: " + nome + " Idade: " + idade + " Peso: " + peso + " Altura: " + alt + "\n";
				if (idade < 18) {
					contIdade++;
				}
				mediaIdade += idade;
				mediaAltura += alt;

				if (peso > 80) {
					somaPeso += peso;
				}
				txt2 = txt;
			}
			txt = "";
			System.out.println("Time: " + time + "\n" + txt2);
		}
		System.out.println("a quantidade de jogadores com idade inferior a 18 anos: "+contIdade);
		System.out.println("a m�dia das idades dos jogadores de cada time"+(mediaIdade/j));
		System.out.println("a m�dia das alturas de todos os jogadores do campeonato: "+(mediaAltura/22));
		System.out.println("a porcentagem de jogadores com mais de 80kg entre todos os jogadores do campeonato: "+(somaPeso/22*100)+"%");

	}

}
