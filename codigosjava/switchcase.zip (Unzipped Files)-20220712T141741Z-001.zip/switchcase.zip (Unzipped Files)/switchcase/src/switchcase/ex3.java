package switchcase;

import java.util.Scanner;

public class ex3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double res1, res2;
		System.out.println("Digite a quantidade de livros:");
		int qtdlivro = sc.nextInt();

		res1 = (0.25 * qtdlivro) + 7.50;
		res2 = (0.50 * qtdlivro) + 2.50;
		
		if(res1>res2) {
			System.out.println("Melhor op��o � o crit�rio A");
		}else if(res2>res1) {
			System.out.println("Melhor op��o � o crit�rio B");
		}else {
			System.out.println("Os dois crit�rios s�o iguais");
		}
		//n tem como usar switch case
		
	}

}
