package switchcase;

import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double imp = 0;
		double preco = 0;
		double ptotal = 0;
		double pimp = 0;
		System.out.println("Digite o c�digo do produto:");
		int cod = sc.nextInt();
		System.out.println("Digite o peso:");
		double peso = sc.nextDouble();
		System.out.println("Digite o c�digo do pa�s:");
		int pais = sc.nextInt();

		switch (pais) {
		case 1:
			imp = 0;
			break;
		case 2:
			imp = 0.15;
			break;
		case 3:
			imp = 0.25;
			break;
		default:
			System.out.println("Pa�s invalido!");
			break;
		}

		switch (cod) {
		case 1:
			preco = peso * 100;
			pimp = preco * imp;
			ptotal = preco + pimp;
			break;

		case 2:
			preco = peso * 100;
			pimp = preco * imp;
			ptotal = preco + pimp;
			break;
		case 3:
			preco = peso * 100;
			pimp = preco * imp;
			ptotal = preco + pimp;
			break;

		case 4:
			preco = peso * 100;
			pimp = preco * imp;
			ptotal = preco + pimp;
			break;
		case 5:
			preco = peso * 250;
			pimp = preco * imp;
			ptotal = preco + pimp;
			break;

		case 6:
			preco = peso * 250;
			pimp = preco * imp;
			ptotal = preco + pimp;
			break;
		case 7:
			preco = peso * 250;
			pimp = preco * imp;
			ptotal = preco + pimp;
			break;

		case 8:
			preco = peso * 350;
			pimp = preco * imp;
			ptotal = preco + pimp;
			break;
		case 9:
			preco = peso * 350;
			pimp = preco * imp;
			ptotal = preco + pimp;
			break;

		case 10:
			preco = peso * 250;
			pimp = preco * imp;
			ptotal = preco + pimp;
			break;
		default:
			System.out.println("N�mero invalido");
		}
		System.out.println("Pre�o " + preco);
		System.out.println("Imposto " + pimp);
		System.out.println("total: " + ptotal);
	}
}
