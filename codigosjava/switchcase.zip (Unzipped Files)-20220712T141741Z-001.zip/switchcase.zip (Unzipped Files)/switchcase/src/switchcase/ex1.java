package switchcase;

import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double aum = 0,novosal = 0;
		System.out.println("Digite o c�digo da fun��o:");
		int cod = sc.nextInt();
		System.out.println("Digite seu sal�rio:");
		double sal = sc.nextDouble();
		switch(cod) {
		case 1:
			aum = sal*0.5;
			novosal = aum+sal;
			break;
		case 2:
			aum = sal*0.35;
			novosal = aum+sal;
			break;
		case 3:
			aum = sal*0.20;
			novosal = aum+sal;
			break;
		case 4:
			aum = sal*0.1;
			novosal = aum+sal;
			break;
		case 5:
			aum = 0;
			novosal = aum+sal;
			break;
		}
		System.out.println("Aumento: "+aum);
		System.out.println("Novo sal�rio: "+novosal);
	}

}
