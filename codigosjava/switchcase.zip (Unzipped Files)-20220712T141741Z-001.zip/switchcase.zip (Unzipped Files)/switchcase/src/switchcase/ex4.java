package switchcase;

import java.util.Scanner;

public class ex4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Double total = null;
		System.out.println("Digite o valor da compra:");
		double valor = sc.nextDouble();
		
		System.out.println("Digite a sua forma de pagamento:"
				+ "\n1 - Pagamento � vista"
				+ "\n2 - Pagamento com cheque pr�-datado para 30 dias"
				+ "\n3 - Pagamento parcelado em 6 vezes"
				+ "\n4  -Pagamento parcelado em 12 vezes");
		int x = sc.nextInt();
		
		switch(x) {
		case 1:
			total = valor * 0.85;
			break;
		case 2:
			total = valor * 0.9;
			break;
		case 3:
			total = valor/6;
			System.out.println("6 parcelas");
			break;
		case 4:
			total = valor/12;
			System.out.println("12 parcelas");
			break;
		}
		
		System.out.println("Valor da compra: "+valor);
		System.out.println("Valor final: "+total);
		
		
	}

}
