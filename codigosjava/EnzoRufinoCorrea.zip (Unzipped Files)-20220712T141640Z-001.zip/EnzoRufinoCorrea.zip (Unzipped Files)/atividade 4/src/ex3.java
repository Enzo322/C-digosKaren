import java.util.Scanner;

public class ex3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int dia, mes, ano;
		int dia2, mes2, ano2;
		System.out.println("Digite o dia:");
		dia = sc.nextInt();
		System.out.println("Digite o m�s");
		mes = sc.nextInt();
		System.out.println("Digite o ano:");
		ano = sc.nextInt();
		
		System.out.println("Digite outro dia:");
		dia2 = sc.nextInt();
		System.out.println("Digite outro m�s");
		mes2 = sc.nextInt();
		System.out.println("Digite outro ano:");
		ano2 = sc.nextInt();
		
		if(ano>ano2) {
			System.out.println(dia+"/"+mes+"/"+ano+" � maior do que "+dia2+"/"+mes2+"/"+ano2);
		}else if(ano2>ano){
			System.out.println(dia2+"/"+mes2+"/"+ano2+" � maior do que "+dia+"/"+mes+"/"+ano);
		}else {
			if(mes>mes2) {
				System.out.println(dia+"/"+mes+"/"+ano+" � maior do que "+dia2+"/"+mes2+"/"+ano2);
			}else if(mes2>mes) {
				System.out.println(dia2+"/"+mes2+"/"+ano2+" � maior do que "+dia+"/"+mes+"/"+ano);
			}else {
				if(dia>dia2) {
					System.out.println(dia+"/"+mes+"/"+ano+" � maior do que "+dia2+"/"+mes2+"/"+ano2);
				}else if(dia2>dia) {
					System.out.println(dia2+"/"+mes2+"/"+ano2+" � maior do que "+dia+"/"+mes+"/"+ano);
				}else {
					System.out.println("As datas s�o iguais");
				}
			}
		}

	}

}
