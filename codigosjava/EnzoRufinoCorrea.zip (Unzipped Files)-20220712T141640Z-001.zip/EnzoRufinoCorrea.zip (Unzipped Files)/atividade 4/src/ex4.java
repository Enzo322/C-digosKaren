import java.util.Scanner;

public class ex4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int hora,min,hora2,min2,tempoh,tempom;
		
		System.out.println("Digite a hora do in�cio do jogo:");
		hora = sc.nextInt();
		System.out.println("Digite o minuto do in�cio do jogo");
		min = sc.nextInt();
		
		System.out.println("Digite a hora do t�rmino do jogo:");
		hora2 = sc.nextInt();
		System.out.println("Digite o minuto do t�rmino do jogo");
		min2 = sc.nextInt();
		
		tempoh = hora-hora2;
		tempom = min-min2;
		if(tempoh<24) {
			System.out.println("Voc� jogou por "+tempoh+" horas e "+tempom+" minutos");
		}else {
			System.out.println("Voc� passou de 24 horas jogando esse jogo :(");
		}

	}

}
