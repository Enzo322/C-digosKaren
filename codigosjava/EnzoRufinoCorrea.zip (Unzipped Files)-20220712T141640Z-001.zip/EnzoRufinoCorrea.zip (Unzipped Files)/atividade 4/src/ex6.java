import java.util.Scanner;

public class ex6 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite o c�digo correspondente:");
		System.out.println("1 - Imposto"
				+ "\n2 - Novo Sal�rio"
				+ "\n3 - Classifica��o");
		int cod = sc.nextInt();
		
		if(cod == 1) {
			System.out.println("Digite seu sal�rio:");
			double sal = sc.nextDouble();
			
			if(sal<500) {
				double imposto = sal*0.05;
				System.out.println("O valor do imposto � de "+imposto);
			}else if(sal<=850) {
				double imposto = sal*0.1;
				System.out.println("O valor do imposto � de "+imposto);
			}else if(sal>850) {
				double imposto = sal*0.15;
				System.out.println("O valor do imposto � de "+imposto);
			}
			
		}else if(cod == 2) {
			System.out.println("Digite seu sal�rio:");
			double sal = sc.nextDouble();
			
			if(sal<450) {
				double novosalario = sal+100;
				System.out.println("O valor do novo sal�rio � de "+novosalario);
			}else if(sal<750) {
				double novosalario = sal+75;
				System.out.println("O valor do novo sal�rio � de "+novosalario);
			}else if(sal>1500) {
				double novosalario = sal+50;
				System.out.println("O valor do novo sal�rio � de "+novosalario);
			}else {
				double novosalario = sal+25;
				System.out.println("O valor do novo sal�rio � de "+novosalario);
			}
			
		}else if(cod == 3) {
			System.out.println("Digite seu sal�rio:");
			double sal = sc.nextDouble();
			
			if(sal<=700) {
				System.out.println("Voc� � mal remunerado");
			}else {
				System.out.println("Voc� � bem remunerado");
			}
		}

	}

}
