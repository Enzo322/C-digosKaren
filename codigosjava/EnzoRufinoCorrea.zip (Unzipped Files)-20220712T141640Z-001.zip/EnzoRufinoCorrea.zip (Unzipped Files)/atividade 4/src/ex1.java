import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num;
		double x,y,res;
		System.out.println("Digite 1 para somar dois n�meros ou 2 para raiz quadrada:");
		num = sc.nextInt();
		if(num == 1) {
			System.out.println("Digite dois n�meros seguidos:");
			x = sc.nextDouble();
			y = sc.nextDouble();
			res = x+y;
			System.out.println("A soma �: "+res);
		}else if(num ==2){
			System.out.println("Digite um n�mero");
			x = sc.nextDouble();
			res = Math.sqrt(x);
			System.out.println("A raiz quadrada de "+x+" � "+res);
		}else {
			System.out.println("N�mero invalido");
		}

	}

}
