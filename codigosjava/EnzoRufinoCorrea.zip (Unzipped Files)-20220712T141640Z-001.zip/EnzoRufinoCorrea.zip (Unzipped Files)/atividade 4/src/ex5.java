import java.util.Scanner;

public class ex5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cod;
		double sal,rea;
		System.out.println("Digite o c�digo correspondente ao seu cargo:");
		System.out.println("1 - Escritu�rio"
				+ "\n2 - Secret�rio"
				+ "\n3  - Caixa"
				+ "\n4 - Gerente"
				+ "\n5 - Diretor");
		//1 - 50% 2 - 35% 3 - 20% 4 - 10% 5 - n�o tem aumento
		cod = sc.nextInt();
		System.out.println("Digite seu sal�rio:");
		sal = sc.nextDouble();
		
		if(cod == 1) {
			rea = sal * 0.5;
			System.out.println("Seu aumento � de "+rea+
			"\nSeu novo sal�rio � de "+(rea+sal));
		}else if(cod == 2) {
			rea = sal * 0.35;
			System.out.println("Seu aumento � de "+rea+
			"\nSeu novo sal�rio � de "+(rea+sal));
		}else if(cod == 3) {
			rea = sal * 0.20;
			System.out.println("Seu aumento � de "+rea+
			"\nSeu novo sal�rio � de "+(rea+sal));
		}else if(cod == 4) {
			rea = sal * 0.10;
			System.out.println("Seu aumento � de "+rea+
			"\nSeu novo sal�rio � de "+(rea+sal));
		}else if(cod == 5) {
			System.out.println("Voc� n tem aumento"
					+ "\nSeu sal�rio � de"+sal);
		}
		

	}

}
