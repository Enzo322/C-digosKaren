import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int dia, mes, ano, hora,min;
		System.out.println("Digite o dia:");
		dia = sc.nextInt();
		System.out.println("Digite o m�s");
		mes = sc.nextInt();
		System.out.println("Digite o ano:");
		ano = sc.nextInt();
		System.out.println("Digite a hora:");
		hora = sc.nextInt();
		System.out.println("Digite o minuto");
		min = sc.nextInt();
		if(mes == 1) {
			System.out.println(dia+" de janeiro de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 2) {
			System.out.println(dia+" de fevereiro de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 3) {
			System.out.println(dia+" de mar�o de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 4) {
			System.out.println(dia+" de abril de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 5) {
			System.out.println(dia+" de maio de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 6) {
			System.out.println(dia+" de junho de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 7) {
			System.out.println(dia+" de julho de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 8) {
			System.out.println(dia+" de agosto de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 9) {
			System.out.println(dia+" de setembro de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 10) {
			System.out.println(dia+" de outubro de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 11) {
			System.out.println(dia+" de novembro de "+ano);
			System.out.println(hora+":"+min);
		}else if(mes == 12) {
			System.out.println(dia+" de dezembro de "+ano);
			System.out.println(hora+":"+min);
		}else {
			System.out.println("M�s invalido");
		}
	}

}
