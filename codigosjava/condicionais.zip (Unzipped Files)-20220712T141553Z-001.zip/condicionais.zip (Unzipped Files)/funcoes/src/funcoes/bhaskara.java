package funcoes;

import java.util.Scanner;

public class bhaskara {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double a,b,c,x,delta,x1,x2;
		System.out.println("informe o valor de a:");
		a = sc.nextDouble();
		System.out.println("informe o valor de b:");
		b = sc.nextDouble();
		System.out.println("informe o valor de c:");
		c = sc.nextDouble();
		delta = Math.pow(b, 2) - 4*a*c;
		x1 = (-b+Math.sqrt(delta))/2*a;
		x2 = (-b-Math.sqrt(delta))/2*a;
		System.out.println("O valor de x1 �:"+x1);
		System.out.println("O valor de x2 �:"+x2);
	}

}
