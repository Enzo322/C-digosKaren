package funcoes;

import java.util.Scanner;

public class condicionais {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite a nota 1:");
		double nota1 = sc.nextDouble();
		System.out.println("Digite a nota 2:");
		double nota2 = sc.nextDouble();
		System.out.println("Digite a nota 3:");
		double nota3 = sc.nextDouble();
		double media = (nota1*2)+(nota2*3)+(nota3*5)/10;
		if(media<5) {
			System.out.println("conceito E");
		}if(media>=5&&media<6) {
			System.out.println("Conceito D");
		}if(media>=6 && media<7) {
			System.out.println("Conceito C");
		}if(media>=7 && media<8) {
			System.out.println("Conceito B");
		}if(media>=8 && media<=10) {
			  System.out.println("Conceito A");
		}
		
	}
}
