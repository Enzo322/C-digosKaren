package funcoes;

import java.util.Scanner;

public class func {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double num = sc.nextDouble();
		
		double quad = Math.pow(num, 2);
		double cubo = Math.pow(num, 3);
		double r2 = Math.sqrt(num);
		double r3 = Math.cbrt(num);
		
		System.out.println(quad);
		System.out.println(cubo);
		System.out.println(r2);
		System.out.println(r3);
			
	}

}
