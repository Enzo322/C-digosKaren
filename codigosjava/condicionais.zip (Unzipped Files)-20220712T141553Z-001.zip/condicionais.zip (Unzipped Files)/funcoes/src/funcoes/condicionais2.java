package funcoes;

import java.util.Scanner;

public class condicionais2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite a nota 1:");
		double nota1 = sc.nextDouble();
		System.out.println("Digite a nota 2:");
		double nota2 = sc.nextDouble();
		System.out.println("Digite a nota 3:");
		double nota3 = sc.nextDouble();
		double media = (nota1 + nota2 + nota3) / 3;
		double mediaexame;
		if (media < 3) {
			System.out.println("reprovado");
		} else if (media < 5.9) {
			System.out.println("exame");
			mediaexame = 6 - media;
			System.out.println("� necess�rio tirar " + mediaexame + " para passar");
		} else {
			System.out.println("Aprovado");
		}

	}

}
