package funcoes;

import java.util.Scanner;

public class condicionais6 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num1;
		System.out.println("Digite um numero:");
		num1 = sc.nextInt();

		if (num1 % 2 == 0) {
			System.out.println("O n�mero � par");
		}
		if (num1 % 2 == 1) {
			System.out.println("O n�mero � impar");
		}
	}

}
