package funcoes;

import java.util.Scanner;

public class condicionais7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double i;
		int a, b, c;
		System.out.println("Digite o numero i:");
		i = sc.nextDouble();
		System.out.println("Digite o numero a:");
		a = sc.nextInt();
		System.out.println("Digite o numero b:");
		b = sc.nextInt();
		System.out.println("Digite o numero c:");
		c = sc.nextInt();

		if (i == 1) {
			if (a < b && a < c) {
				if (b < c) {
					System.out.println(a + ", " + b + ", " + c);
				}
				if (c < b) {
					System.out.println(a + ", " + c + ", " + b);
				}
			}
			if (b < a && b < c) {
				if (a < c) {
					System.out.println(b + ", " + a + ", " + c);
				}
				if (c < a) {
					System.out.println(b + ", " + c + ", " + a);
				}
			}
			if (c < a && c < b) {
				if (a < b) {
					System.out.println(c + ", " + a + ", " + b);
				}
				if (b < a) {
					System.out.println(c + ", " + b + ", " + a);
				}
			}
		}
		if (i == 2) {
			if (a > b && a > c) {
				if (b > c) {
					System.out.println(a + ", " + b + ", " + c);
				}
				if (c > b) {
					System.out.println(a + ", " + c + ", " + b);
				}
			}
			if (b > a && b > c) {
				if (a > c) {
					System.out.println(b + ", " + a + ", " + c);
				}
				if (c > a) {
					System.out.println(b + ", " + c + ", " + a);
				}
			}
			if (c > a && c > b) {
				if (a > b) {
					System.out.println(c + ", " + a + ", " + b);
				}
				if (b > a) {
					System.out.println(c + ", " + b + ", " + a);
				}
			}
		}
		if (i == 3) {
			if (a < b && a < c) {
				if (b < c) {
					System.out.println(a + ", " + c + ", " + b);
				}
				if (c < b) {
					System.out.println(a + ", " + b + ", " + c);
				}
			}
			if (b < a && b < c) {
				if (a < c) {
					System.out.println(b + ", " + c + ", " + a);
				}
				if (c < a) {
					System.out.println(b + ", " + a + ", " + c);
				}
			}
			if (c < a && c < b) {
				if (a < b) {
					System.out.println(c + ", " + b + ", " + a);
				}
				if (b < a) {
					System.out.println(c + ", " + a + ", " + b);
				}
			}
		}

	}

}
