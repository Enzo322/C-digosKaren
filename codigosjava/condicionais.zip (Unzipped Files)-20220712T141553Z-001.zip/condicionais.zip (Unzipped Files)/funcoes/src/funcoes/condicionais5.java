package funcoes;

import java.util.Scanner;

public class condicionais5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite numeros em ordem crescente:");
		int num1 = sc.nextInt();
		System.out.println("Digite numeros em ordem crescente:");
		int num2 = sc.nextInt();
		System.out.println("Digite numeros em ordem crescente:");
		int num3 = sc.nextInt();
		System.out.println("Digite um numero aleat�rio:");
		int num4 = sc.nextInt();

		if (num1 < num2 && num1 < num3 && num1<num4) {
			if (num2 < num3 && num2< num4) {
			} else {
				System.out.println(num1 + "," + num3 + "," + num2);
			}
		} else if (num2 < num1 && num2 < num3) {
			if (num1 < num3) {
				System.out.println(num2 + "," + num1 + "," + num3);
			} else {
				System.out.println(num2 + "," + num3 + "," + num1);
			}
		} else if (num3 < num2 && num3 < num1) {
			if (num1 < num2) {
				System.out.println(num3 + "," + num1 + "," + num2);
			} else {
				System.out.println(num3 + "," + num2 + "," + num1);
			}
		}
		sc.close();
	}

}
