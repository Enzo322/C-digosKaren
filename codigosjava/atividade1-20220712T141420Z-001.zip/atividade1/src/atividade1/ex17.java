package atividade1;

import java.util.Scanner;

public class ex17 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite o raio:");
		double num1 = sc.nextDouble();

		double per = 2 * Math.PI * num1;
		double area = Math.PI * Math.pow(num1, 2);
		System.out.println(per);
		System.out.println(area);
		sc.close();

	}

}
