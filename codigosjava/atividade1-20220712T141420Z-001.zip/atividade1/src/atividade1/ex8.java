package atividade1;

public class ex8 {

	public static void main(String[] args) {
		System.out.println("Minha idade � "+16);

	}

}
