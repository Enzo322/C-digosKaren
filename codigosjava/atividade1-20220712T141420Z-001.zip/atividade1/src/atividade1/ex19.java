package atividade1;

public class ex19 {

	public static void main(String[] args) {
		double media = (8+9+7)/3;
		double media2 = (4+5+6)/3;
		double somamedia = media+media2;
		double mediamedia = somamedia/2;
		System.out.println(somamedia);
		System.out.println(mediamedia);

	}

}
