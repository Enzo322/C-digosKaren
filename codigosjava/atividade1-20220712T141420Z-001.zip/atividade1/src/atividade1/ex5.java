package atividade1;

public class ex5 {

	public static void main(String[] args) {
		double media = (8+9+7)/3;
		System.out.println(media);
	}

}
