package atividade1;

import java.util.Scanner;

public class ex9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite um n�mero inteiro:");
		int num = sc.nextInt();
		System.out.println(num);
		sc.close();

	}

}
