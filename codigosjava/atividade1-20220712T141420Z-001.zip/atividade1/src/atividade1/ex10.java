package atividade1;

import java.util.Scanner;

public class ex10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite um n�mero inteiro:");
		int num = sc.nextInt();
		int sus = num+1;
		int ant = num-1;
		System.out.println(sus);
		System.out.println(ant);
		sc.close();

	}

}
