package atividade1;

import java.util.Scanner;

public class ex15 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite dois numeros em sequ�ncia:");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		
		double media = (num1 + num2)/2;
		
		System.out.println("M�dia "+media);
		sc.close();

	}

}
