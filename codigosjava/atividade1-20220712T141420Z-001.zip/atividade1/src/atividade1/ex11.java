package atividade1;

import java.util.Scanner;

public class ex11 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite seu nome:");
		String nome = sc.next();
		System.out.println("Digite seu endere�o:");
		String end = sc.nextLine();
		System.out.println("Digite seu telefone:");
		int tel = sc.nextInt();
		System.out.println("Nome: "+nome
				+"\nEndere�o: "+end
				+"\nTelefone: "+tel);
		sc.close();

	}

}
