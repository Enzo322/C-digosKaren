package atividade1;

import java.util.Scanner;

public class ex18 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite a base e altura sequ�ncia:");
		double num1 = sc.nextDouble();
		double num2 = sc.nextDouble();
		
		double area = (num1*num2)/2;
		
		System.out.println(area);
		sc.close();

	}

}
