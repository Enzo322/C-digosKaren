package atividade1;

public class ex6 {

	public static void main(String[] args) {
		int x = 365;
		System.out.println(x);
	}

}
