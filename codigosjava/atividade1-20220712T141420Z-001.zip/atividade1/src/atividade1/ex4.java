package atividade1;

public class ex4 {

	public static void main(String[] args) {
		System.out.println(28*43);
	}

}
