package atividade1;

import java.util.Scanner;

public class ex14 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite um n�mero:");
		int num = sc.nextInt();
		double terca = (double)num/3;
		System.out.println(terca);
		sc.close();

	}

}
