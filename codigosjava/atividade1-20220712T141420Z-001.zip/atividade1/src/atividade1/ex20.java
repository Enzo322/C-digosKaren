package atividade1;

import java.util.Scanner;

public class ex20 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Idade em anos:");
		int ano = sc.nextInt();
		System.out.println("Idade em meses");
		int mes = sc.nextInt();
		System.out.println("Idade em dias");
		int dia = sc.nextInt();
		
		int dias = (ano*365)+(mes*30)+dia;
	
		System.out.println(dias);
		
		sc.close();

	}

}
