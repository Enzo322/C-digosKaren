package atividade1;

import java.util.Scanner;

public class ex16 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite a base e altura sequ�ncia:");
		double num1 = sc.nextDouble();
		double num2 = sc.nextDouble();
		
		double per = (num1*2) + (num2*2);
		double area = num1*num2;
		System.out.println(per);
		System.out.println(area);
		sc.close();

	}

}
