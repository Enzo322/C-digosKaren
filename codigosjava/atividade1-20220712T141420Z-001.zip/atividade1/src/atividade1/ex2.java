package atividade1;

public class ex2 {

	public static void main(String[] args) {
		System.out.println("� preciso fazer todos os algoritmos para aprender");

	}

}
