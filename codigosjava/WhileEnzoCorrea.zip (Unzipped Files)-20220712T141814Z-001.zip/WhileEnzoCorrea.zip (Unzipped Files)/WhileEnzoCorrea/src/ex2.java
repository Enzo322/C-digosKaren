import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite um n�mero indeterminado de valores, at� for igual a 0;");
		double i = sc.nextDouble();
		while(i!=0) {
			System.out.println(i);
			System.out.println("Quadrado: "+Math.pow(i, 2)+"\nCubo: "+Math.pow(i, 3)+"\nRaiz: "+Math.sqrt(i));
			i = sc.nextDouble();
		}
		

	}

}
