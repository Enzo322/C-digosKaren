import java.util.Scanner;

public class ex4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double sal = 1;
		double somaval = 0;
		int cont = 0;
		while (sal != 0) {
			System.out.println("Digite seu sal�rio m�nimo:");
			sal = sc.nextDouble();
			if(sal == 0) {
				break;
			}
			System.out.println("Escolha as op��es:\n" + "1 - residencial" + "\n2 - Comercial" + "\n3 - Industrial");
			int op = sc.nextInt();

			double kw = sal / 8;
			double val = 0;
			System.out.println("Valor QuiloWatts: "+kw);
			switch (op) {
			case 1:
				val = kw * 1.05;
				somaval += val;
				break;
			case 2:
				val = kw * 1.10;
				somaval += val;
				break;
			case 3:
				val = kw * 1.15;
				somaval += val;
				break;

			default:
				System.out.println("N�mero ivalido!");
				break;
			}
			if (val >= 500 && val < 1000) {
				cont++;
			}
			System.out.println("Valor a ser pago: "+val);
		}
		System.out.println("Faturamento geral da empresa: " + somaval);
		System.out.println("a quantidade de consumidores que pagam entre R$500,00 e R$1.000,00: "+cont);

		sc.close();

	}

}
