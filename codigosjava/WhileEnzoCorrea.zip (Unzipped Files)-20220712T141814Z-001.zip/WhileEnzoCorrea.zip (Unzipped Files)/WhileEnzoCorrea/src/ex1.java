import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Carlos, digite seu sal�rio:");
		double SalCarlos = sc.nextDouble();

		double SalJoao = SalCarlos / 3;
		int qtdmes = 0;
		while (SalCarlos >= SalJoao) {
			SalCarlos += SalCarlos * 0.02;
			SalJoao += SalJoao * 0.05;
			qtdmes++;
		}
		System.out.println("Demorou " + qtdmes + " para a renda fixa de Jo�o ultrapassar a de Carlos");
		sc.close();
	}

}
