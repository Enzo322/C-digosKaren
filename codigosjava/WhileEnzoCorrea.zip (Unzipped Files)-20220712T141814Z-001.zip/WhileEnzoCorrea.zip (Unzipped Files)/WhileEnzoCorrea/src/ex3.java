import java.util.Scanner;

public class ex3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Digite um n�mero indeterminado de valores, at� for igual a 0;");
		double i = sc.nextDouble();
		double x = 0;
		int cont = 0;
		int maior = 0, menor = 999999999;
		double somamedia = 0;
		double impar = 0;
		int contpar=0;
		while (i != 30000) {
			x += i;

			cont++;

			if (i > maior) {
				maior = (int) i;
			} else if (i < menor) {
				menor = (int) i;
			}

			if (i % 2 == 0) {
				somamedia += i;
				contpar++;
			} else {
				impar++;
			}

			i = sc.nextDouble();
		}
		
		double media = somamedia / contpar;
		double por = (impar/cont)*100;
		System.out.println("Soma: "+x+"\nQuantidade: "+cont+"\nMaior: "+maior+"\nMenor: "+menor+"\nMedia dos pares: "+media+"\nPorcentagem de impares: "+por+"%");

	}

}
