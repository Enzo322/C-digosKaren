import java.util.Scanner;

public class ex1 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int num;
		do {
			System.out.println("Entre com um numero ");
			num = scan.nextInt();
			for (int i = 2; i <= num; i++) {
				String primo = "primo";
				for (int j = 2; j < i; j++) {
					if (i % j == 0) {
						primo = "n�o primo";
					}
				}
				if (primo == "primo") {
					System.out.println(i);
				}
			}

		} while (num >= 1);
	}
}